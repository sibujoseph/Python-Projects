from ._line import Line
from ._colorbar import ColorBar
from plotly.graph_objs.bar.marker import colorbar
