from ._stream import Stream
from ._line import Line
from ._increasing import Increasing
from plotly.graph_objs.candlestick import increasing
from ._hoverlabel import Hoverlabel
from plotly.graph_objs.candlestick import hoverlabel
from ._decreasing import Decreasing
from plotly.graph_objs.candlestick import decreasing
