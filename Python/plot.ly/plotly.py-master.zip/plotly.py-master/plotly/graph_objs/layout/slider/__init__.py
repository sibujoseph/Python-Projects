from ._transition import Transition
from ._step import Step
from ._pad import Pad
from ._font import Font
from ._currentvalue import Currentvalue
from plotly.graph_objs.layout.slider import currentvalue
