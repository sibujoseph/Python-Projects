from ._hoverlabel import Hoverlabel
from plotly.graph_objs.layout.scene.annotation import hoverlabel
from ._font import Font
