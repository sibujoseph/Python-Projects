from ._stream import Stream
from ._lightposition import Lightposition
from ._lighting import Lighting
from ._hoverlabel import Hoverlabel
from plotly.graph_objs.mesh3d import hoverlabel
from ._contour import Contour
from ._colorbar import ColorBar
from plotly.graph_objs.mesh3d import colorbar
