pythonic plotly API for use in Jupyter

Package Install
---------------

**Prerequisites**
- [node](http://nodejs.org/)

```bash
npm install --save plotlywidget
```
